package com.fredbeardinerrush.service;

import com.fredbeardinerrush.model.Direction;
import com.fredbeardinerrush.model.MazeGrid;
import com.fredbeardinerrush.model.Player;
import com.fredbeardinerrush.model.Position;

public class GameEngine {
    private final IMaze maze;
    private final IPlayer player1;
    private final IPlayer player2;
    private boolean gameOver;
    private String winnerText;

    // Tally tracking
    private int p1Wins = 0;
    private int p2Wins = 0;

    private final Position p1Spawn;
    private final Position p2Spawn;

    public GameEngine(int width, int height, IMazeLoader loader) {
        this.maze = new MazeGrid(width, height, loader);
        this.p1Spawn = loader != null ? loader.getSpawnPosition() : new Position(1, 1);
        this.p2Spawn = new Position(width - 2, 1); // Default right-side spawn alternative

        this.player1 = new Player(p1Spawn, true);
        this.player2 = new Player(p2Spawn, false);
        this.gameOver = false;
        this.winnerText = "";
    }

    public void update() {
        if (gameOver)
            return;

        player1.move(maze);
        player2.move(maze);

        if (maze.getRemainingDots(true) == 0) {
            gameOver = true;
            p1Wins++;
            winnerText = "Fredbear (Player 1) cleared their side and Wins!";
        } else if (maze.getRemainingDots(false) == 0) {
            gameOver = true;
            p2Wins++;
            winnerText = "Springbonnie (Player 2) cleared their side and Wins!";
        }
    }

    public void resetMatch(Position p1Start, Position p2Start) {
        maze.resetMaze();
        player1.setPosition(p1Start);
        player2.setPosition(p2Start);
        player1.setDirection(Direction.RIGHT);
        player2.setDirection(Direction.LEFT);
        gameOver = false;
        winnerText = "";
    }

    public IMaze getMaze() {
        return maze;
    }

    public IPlayer getPlayer1() {
        return player1;
    }

    public IPlayer getPlayer2() {
        return player2;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public String getWinnerText() {
        return winnerText;
    }

    public int getP1Wins() {
        return p1Wins;
    }

    public int getP2Wins() {
        return p2Wins;
    }
}